// ignore: file_names
class Productos {
  String producto;
  String stock;
  String foto;

  Productos({required this.producto, required this.stock, required this.foto});
}
