class Persona {
  String nombre;
  String? foto;
  String apepat;
  Persona({required this.nombre, foto, required this.apepat});
}
